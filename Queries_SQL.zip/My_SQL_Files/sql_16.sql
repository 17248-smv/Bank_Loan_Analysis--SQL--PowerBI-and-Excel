select loan_status 
from financial_loan


