select count('ix>id') as Total_loan_Applications 
from financial_loan