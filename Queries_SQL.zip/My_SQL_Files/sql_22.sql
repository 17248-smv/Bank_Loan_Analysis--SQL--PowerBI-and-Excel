select count('ix>id') as Bad_Loan_Applications 
from financial_loan
where loan_status = 'Charged Off'