select sum(loan_amount) as MTD_Total_Funded_Amount 
from financial_loan
where month(str_to_date(issue_date,'%d-%m-%Y')) = 12 and year(STR_TO_DATE(issue_date, '%d-%m-%Y')) = 2021;