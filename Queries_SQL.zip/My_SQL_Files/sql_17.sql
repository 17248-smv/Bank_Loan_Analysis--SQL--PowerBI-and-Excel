select round((count(case when loan_status = 'Fully Paid' or loan_status = 'Current' then 'ix>id' end) * 100) / count('ix>id'), 0) as Good_loan_percentage
from financial_loan