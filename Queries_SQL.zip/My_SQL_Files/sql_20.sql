select sum(total_payment) as Good_Loan_Received_Amount
from financial_loan 
where loan_status = 'Fully Paid' or loan_status = 'Current'