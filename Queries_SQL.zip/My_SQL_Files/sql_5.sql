select sum(loan_amount) as Total_Funded_Amount 
from financial_loan