SELECT COUNT(*) AS MTD_Total_loan_Applications
FROM financial_loan
WHERE MONTH(STR_TO_DATE(issue_date, '%d-%m-%Y')) = 12
  AND YEAR(STR_TO_DATE(issue_date, '%d-%m-%Y')) = 2021;

