SELECT loan_status, 
       SUM(total_payment) AS MTD_Total_Amount_Received, 
       SUM(loan_amount) AS MTD_Total_Funded_Amount
FROM financial_loan
WHERE MONTH(STR_TO_DATE(issue_date, '%d-%m-%Y')) = 12
GROUP BY loan_status;
