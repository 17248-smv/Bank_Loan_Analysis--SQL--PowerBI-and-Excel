SELECT 
    home_ownership,
    COUNT('ix>id') AS Total_Loan_Applications,
    SUM(loan_amount) AS Total_Funded_Amount,
    SUM(total_payment) AS Total_Received_Amount
FROM 
    financial_loan
    where grade = 'A' and address_state = 'CA'
GROUP BY home_ownership
ORDER BY COUNT('ix>id') desc

