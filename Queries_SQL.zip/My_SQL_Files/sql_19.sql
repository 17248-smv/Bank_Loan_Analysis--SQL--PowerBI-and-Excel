select sum(loan_amount) as Good_Loan_Funded_Amount
from financial_loan 
where loan_status = 'Fully Paid' or loan_status = 'Current'