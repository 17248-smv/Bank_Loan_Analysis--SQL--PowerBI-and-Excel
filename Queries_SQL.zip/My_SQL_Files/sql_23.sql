select sum(total_payment) as Bad_Loan_Amount_Received
from financial_loan
where loan_status = 'Charged Off'