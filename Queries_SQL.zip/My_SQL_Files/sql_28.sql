SELECT 
    term,
    COUNT('ix>id') AS Total_Loan_Applications,
    SUM(loan_amount) AS Total_Funded_Amount,
    SUM(total_payment) AS Total_Received_Amount
FROM 
    financial_loan
GROUP BY term
ORDER BY term

