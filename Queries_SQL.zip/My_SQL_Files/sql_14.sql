select round(Avg(dti),4)*100 as Avg_DTI 
from financial_loan
where month(str_to_date(issue_date,'%d-%m-%Y')) = 12 and year(STR_TO_DATE(issue_date, '%d-%m-%Y')) = 2021;