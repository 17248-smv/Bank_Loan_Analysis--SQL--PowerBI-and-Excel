select round(avg(int_rate)*100, 2) as Avg_Interest_Rate 
from financial_loan