select loan_status, count('ix>id') as Total_Loan_Applications, sum(total_payment) as Total_Amount_Received, sum(loan_amount) as Total_Funded_Amount, avg(int_rate * 100) as Interest_Rate, avg(dti * 100) as DTI
from financial_loan
group by loan_status
