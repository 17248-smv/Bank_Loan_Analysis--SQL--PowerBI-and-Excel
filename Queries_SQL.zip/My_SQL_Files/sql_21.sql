select (count(case when loan_status = 'Charged off' then 'ix>id' end)* 100) / count('ix>id')  as Bad_Loan_Percentage
from financial_loan