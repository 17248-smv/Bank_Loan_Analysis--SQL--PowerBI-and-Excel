SELECT 
    MONTHNAME(STR_TO_DATE(issue_date, '%d-%m-%Y')) AS Month_Name,
    COUNT('ix>id') AS Total_Loan_Applications,
    SUM(loan_amount) AS Total_Funded_Amount,
    SUM(total_payment) AS Total_Received_Amount
FROM 
    financial_loan
WHERE 
    issue_date IS NOT NULL
GROUP BY 
    MONTH(STR_TO_DATE(issue_date, '%d-%m-%Y')),
    MONTHNAME(STR_TO_DATE(issue_date, '%d-%m-%Y'))
ORDER BY 
    MONTH(STR_TO_DATE(issue_date, '%d-%m-%Y'));
